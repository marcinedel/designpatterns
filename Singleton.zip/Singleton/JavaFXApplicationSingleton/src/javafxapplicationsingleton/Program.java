/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package javafxapplicationsingleton;

/**
 *
 * @author medel
 */
class Program
{
    public static void main(String[] args) {
        // TODO code application logic here
        Uzytkownik uzytkownik = Uzytkownik.zwrocUzytkownika();
        Uzytkownik uzytkownikWInnymMiejscu = Uzytkownik.zwrocUzytkownika();
        
        uzytkownik.zaloguj("Janko", "Jan", "Kowalski", 19, "aa1");
        
        System.out.println(uzytkownik.Login);
        System.out.println(uzytkownikWInnymMiejscu.Login);
        
    }
    
}
