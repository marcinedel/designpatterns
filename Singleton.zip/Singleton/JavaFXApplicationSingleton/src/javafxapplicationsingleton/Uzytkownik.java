/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package javafxapplicationsingleton;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author medel
 */

public class Uzytkownik {

    /**
     * @param args the command line arguments
     */
    private static volatile Uzytkownik _uzytkownik = null;
    private Uzytkownik() {
        if(_uzytkownik != null) {
            throw new RuntimeException("Dostęp zabroniony");
        }
    }
    public static Uzytkownik zwrocUzytkownika() {

        if(_uzytkownik == null) {
            synchronized(Uzytkownik.class) {
                if(_uzytkownik == null) {
                    _uzytkownik = new Uzytkownik();
                }
            }
        }

        return _uzytkownik;
    }
    
    public String Login;

        public String getLogin() {
            return Login;
        }
        private void setLogin(String newLogin) {
            this.Login = newLogin;
        }
    public String Imie;

        public String getImie() {
            return Imie;
        }
        private void setImie(String newImie) {
            this.Imie = newImie;
        }
        
    public String Nazwisko;

        public String getNazwisko() {
            return Nazwisko;
        }
        private void setNazwisko(String newNazwisko) {
            this.Nazwisko = newNazwisko;
        }
        
    public String Token;

        public String getToken() {
            return Token;
        }
        private void setToken(String newToken) {
            this.Token = newToken;
        }
        
    public int Wiek;

        public int getWiek() {
            return Wiek;
        }
        private void setWiek(int newWiek) {
            this.Wiek = newWiek;
        }
        
    
    public void zaloguj( String login, String imie, String nazwisko, int wiek, String token){
        Login=login;
        Imie=imie;
        Nazwisko=nazwisko;
        Token=token;
        Wiek=wiek;
        
    
    }
            
            
        }

