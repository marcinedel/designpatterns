/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package javafxapplicationbuilder;


/**
 *
 * @author medel
 */
public class Program {
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        KreatorOdtwarzaczaHTML kreatorOdtwarzaczaHTML = new KreatorOdtwarzaczaHTML();
        KreatorOdtwarzaczaFlash kreatorOdtwarzaczaFlash = new KreatorOdtwarzaczaFlash();
        Generator generator = new Generator();
        
        //Odtwarzacz odtwarzacz;
        
        generator.Skladaj(kreatorOdtwarzaczaHTML);
        kreatorOdtwarzaczaHTML.ZwrocOdtwarzacz();
        kreatorOdtwarzaczaHTML.ZwrocOdtwarzacz().Pokaz();
        
        generator.Skladaj(kreatorOdtwarzaczaFlash);
        kreatorOdtwarzaczaFlash.ZwrocOdtwarzacz().Pokaz();
        
        
    }
    
}
