/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package javafxapplicationbuilder;



/**
 *
 * @author medel
 */

    
    public class Odtwarzacz {
    
    public String _nazwa;
    public void UstawNazwe(String nazwa)
    {
    _nazwa=nazwa;
    }
    public void Pokaz()
    {
        System.out.println("\n"+_nazwa);
    }
   
}
