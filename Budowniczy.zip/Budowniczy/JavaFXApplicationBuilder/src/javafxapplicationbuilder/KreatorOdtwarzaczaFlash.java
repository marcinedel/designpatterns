/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplicationbuilder;

/**
 *
 * @author medel
 */
class KreatorOdtwarzaczaFlash extends BudowniczyOdtwarzaczy{
    
    private Odtwarzacz _odtwarzacz;
    public KreatorOdtwarzaczaFlash()
    {
        _odtwarzacz = new Odtwarzacz();
    }
    @Override
    public void ZbudujOdtwarzacz() {
        _odtwarzacz.UstawNazwe("Odtwarzacz Flash"); 
    }

    @Override
    public Odtwarzacz ZwrocOdtwarzacz() {
        return _odtwarzacz;
    }
}
