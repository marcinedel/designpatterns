/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplicationfabrykajednostekwojskowych;

/**
 *
 * @author medel
 */
public class Strzelec extends Jednostka{
    
    public Strzelec(int zycie, int doswiadczenie, int silaZniszczenia) {
        super(zycie, doswiadczenie, silaZniszczenia);
    }
    
}
