/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplicationfabrykajednostekwojskowych;

/**
 *
 * @author medel
 */
public class JednostkaFabryka extends Fabryka{

    @Override
    
    public Jednostka stworzJednostke(JednostkaTyp jednostkaTyp) {
        switch (jednostkaTyp)
        {
            case CZOLG:
                return new Czolg(100, 0, 20);
                
            case STRZELEC:
                return new Strzelec(25, 0, 10);
                
            default:
                System.out.println("Nie ma takiego typu");
                
        }
        return null;
    }
    
}
