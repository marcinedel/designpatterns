/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplicationfabrykajednostekwojskowych;

/**
 *
 * @author medel
 */
abstract class Jednostka {
    
    public int zycie;

        public int getzycie() {
            return zycie;
        }
        private void setzycie(int newzycie) {
            this.zycie = newzycie;
        }
        
    public int doswiadczenie;
   
        public int getdoswiadczenie() {
            return doswiadczenie;
        }
        private void setdoswiadczenie(int newdoswiadczenie) {
            this.doswiadczenie = newdoswiadczenie;
        }
        
    public int silaZniszczenia;
   
        public int getsilaZniszczenia() {
            return silaZniszczenia;
        }
        private void setsilaZniszczenia(int newsilaZniszczenia) {
            this.silaZniszczenia = newsilaZniszczenia;
        }
    protected Jednostka(int zycie, int doswiadczenie, int silaZniszczenia)
    {
        this.zycie = zycie;
        this.doswiadczenie = doswiadczenie;
        this.silaZniszczenia = silaZniszczenia;
    }
}
