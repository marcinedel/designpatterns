/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package javafxapplicationfabrykajednostekwojskowych;



/**
 *
 * @author medel
 */
public class Program{
        
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Fabryka fabryka = new JednostkaFabryka();
       
       Jednostka czolg = fabryka.stworzJednostke(JednostkaTyp.CZOLG);
       Jednostka wojskowy = fabryka.stworzJednostke(JednostkaTyp.STRZELEC);
       
        System.out.println(czolg.silaZniszczenia);
        System.out.println(wojskowy.silaZniszczenia);
        System.out.println(czolg.zycie);
        System.out.println(wojskowy.zycie);
        
    }
    
}
