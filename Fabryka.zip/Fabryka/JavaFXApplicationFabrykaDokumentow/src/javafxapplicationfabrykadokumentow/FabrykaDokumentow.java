/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package javafxapplicationfabrykadokumentow;

/**
 *
 * @author medel
 */
public class FabrykaDokumentow {
    
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //
    }
    
}
