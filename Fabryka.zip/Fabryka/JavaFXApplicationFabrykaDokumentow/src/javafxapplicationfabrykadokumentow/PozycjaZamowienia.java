/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplicationfabrykadokumentow;

/**
 *
 * @author medel
 */

    abstract class PozycjaZamowienia
{
    public String Nazwa;

        public String getNazwa() {
            return Nazwa;
        }
        private void setNazwa(String newNazwa) {
            this.Nazwa = newNazwa;
        }
    public int LiczbaSztuk;

        public int getLiczbaSztuk() {
            return LiczbaSztuk;
        }
        private void setLiczbaSztuk(int newLiczbaSztuk) {
            this.LiczbaSztuk = newLiczbaSztuk;
        }
        
    public float CenaSztuka;

        public float getCenaSztuka() {
            return CenaSztuka;
        }
        private void setCenaSztuka(float newCenaSztuka) {
            this.CenaSztuka = newCenaSztuka;
        }
   
}

