/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplicationfabrykadokumentow;

/**
 *
 * @author medel
 */
abstract class Sprzedaz  extends PozycjaZamowienia{
    public void UtworzDokumentSprzedazy (String nazwa, int liczbaSztuk, float cenaSztuka)
    {
        Nazwa = nazwa;
        LiczbaSztuk = liczbaSztuk;
        CenaSztuka = cenaSztuka;
        
    }
    
}
