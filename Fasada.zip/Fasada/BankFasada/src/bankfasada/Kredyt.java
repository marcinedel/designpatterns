/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bankfasada;

/**
 *
 * @author medel
 */
public class Kredyt {
    public boolean PosiadaDobraHistorieKredytowa(Klient klient)
    {
        System.out.println("Sprawdzanie historii kredytowej dla " + klient.Imie);
        return true;
    }
}
