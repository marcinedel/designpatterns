/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bankfasada;

/**
 *
 * @author medel
 */
class Klient {
    public String Imie;

        public String getImie() {
            return Imie;
        }
        private void setImie(String newImie) {
            this.Imie = newImie;
        }
        public void zapytaj( String imie){
        Imie=imie;
}
}

