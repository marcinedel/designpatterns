/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bankfasada;

/**
 *
 * @author medel
 */
public class Hipoteka {
    private Bank _bank = new Bank();
    private Pozyczka _pozyczka = new Pozyczka();
    private Kredyt _kredyt = new Kredyt();

    public boolean CzyKwalifikujeSie(Klient klient, int wartoscZapytaniaKredytowego)
    {
        System.out.println(klient.Imie+" wysłał zapytanie o kredyt hipoteczny o wartosci " + wartoscZapytaniaKredytowego);

        boolean kwalifikujeSie = true;

        if (!_bank.PosiadaWystarczajaceOszczednosci(klient, wartoscZapytaniaKredytowego))
        {
            kwalifikujeSie = false;
        }
        else if (!_pozyczka.NiePosiadaNieOplaconychPozyczek(klient))
        {
            kwalifikujeSie = false;
        }
        else if (!_kredyt.PosiadaDobraHistorieKredytowa(klient))
        {
            kwalifikujeSie = false;
        }

        return kwalifikujeSie;
    }
}
