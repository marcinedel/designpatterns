/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bankfasada;

/**
 *
 * @author medel
 */
public class Program {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Hipoteka hipoteka = new Hipoteka();
        
        Klient klient = new Klient();
        klient.zapytaj("Jan Drążkowski");
        
        boolean kwalifikujeSie = hipoteka.CzyKwalifikujeSie(klient, 125000);
        
          System.out.println("\n" + klient.Imie + " zakfalifikował się jako "+ (kwalifikujeSie ? "Zaakceptowany" : "Odrzucony"));
    }
    
}
