/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autentyfikacjapełnomocnik;

/**
 *
 * @author medel
 */
public class KonkretnyFolder extends Folder{
    
    private String Dane;

    public KonkretnyFolder()
    {
        System.out.println("KonkretnyFolder: Uruchomiony");
        Dane = "Bardzo ważne dane";
    }
    
    @Override
    public String PobierzDane() {
        return Dane;
    }
    
}
