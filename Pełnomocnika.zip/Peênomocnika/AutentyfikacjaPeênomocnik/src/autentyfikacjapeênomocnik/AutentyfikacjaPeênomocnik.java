/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package autentyfikacjapełnomocnik;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author medel
 */
public class AutentyfikacjaPełnomocnik {
    
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pelnomocnik pelnomocnik1 = new Pelnomocnik("zlehaslo");
        System.out.println(pelnomocnik1.PobierzDane());

        Pelnomocnik pelnomocnik2 = new Pelnomocnik("dobrehaslo");
        System.out.println(pelnomocnik2.PobierzDane());
    }
    
}
