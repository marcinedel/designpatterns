/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autentyfikacjapełnomocnik;

/**
 *
 * @author medel
 */
public class Pelnomocnik extends Folder{
    
    private KonkretnyFolder _konkretnyFolder;
    private boolean _autoryzowany;
    private String _haslo = "dobrehaslo";
    
    
    public Pelnomocnik(String haslo)
    {
        if (_haslo == haslo)
        {
            _autoryzowany = true;
            System.out.println("Pelnomocnik: Uruchomony");
        }
    }
    
    @Override
    public String PobierzDane() {
        if (_autoryzowany)
        {
            if (_konkretnyFolder == null)
            {
                _konkretnyFolder = new KonkretnyFolder();
            }

            return "Dane z pełnomocnika to " + _konkretnyFolder.PobierzDane();
        }
        else
        {
            return "Pelnomocnik: Odmowa dostępu";
        }
    }
    
}
