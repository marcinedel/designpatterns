/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kompozyt;

/**
 *
 * @author medel
 */
abstract class Element {
    
    protected String nazwa;

    public Element(String nazwa)
    {
        this.nazwa = nazwa;
    }

    public abstract void Dodaj(Element c);
    public abstract void Usun(Element c);
    public abstract void Pokaz(int poziom);
}
