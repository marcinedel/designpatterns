/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package kompozyt;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author medel
 */
public class Kompozyt extends Element {
    
    private final List<Element> _dzieci = new ArrayList<Element>();
    
    
    public Kompozyt(String nazwa) {
        super(nazwa);
    }
   
    @Override
    public void Dodaj(Element element) {
        _dzieci.add(element);
    }

    @Override
    public void Usun(Element element) {
        _dzieci.remove(element);
    }

    @Override
    public void Pokaz(int poziom) {
        
                for(int i=0;i<poziom;i++)
                {
                    System.out.print("-");
                }
                System.out.print(nazwa+"\n");
                
        for(Element element : _dzieci)
        {
            element.Pokaz(poziom+2);
        }
    }
    
    
    public static void main(String[] args) {
        Kompozyt root = new Kompozyt("root");
        root.Dodaj(new Lisc("Lisc A"));
        root.Dodaj(new Lisc("Lisc B"));

        Kompozyt comp = new Kompozyt("Kompozyt X");
        comp.Dodaj(new Lisc("Lisc XA"));
        comp.Dodaj(new Lisc("Lisc XB"));

        root.Dodaj(comp);
        root.Dodaj(new Lisc("Lisc C"));

        Lisc leaf = new Lisc("Lisc D");
        root.Dodaj(leaf);
        root.Usun(leaf);

        root.Pokaz(1);
    }
    
}
