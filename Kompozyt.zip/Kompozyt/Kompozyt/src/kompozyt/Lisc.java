/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kompozyt;

/**
 *
 * @author medel
 */
public class Lisc extends  Element{

    public Lisc(String nazwa) {
        super(nazwa);
    }

    @Override
    public void Dodaj(Element c) {
        System.out.println("Nie można dodać liścia");    }

    @Override
    public void Usun(Element c) {
        System.out.println("Nie można usunąć liścia");
    }

    @Override
    public void Pokaz(int poziom) {
        for(int i=0;i<poziom;i++)
                {
                    System.out.print("-");
                }
                System.out.print(nazwa+"\n");
    }
    
}
