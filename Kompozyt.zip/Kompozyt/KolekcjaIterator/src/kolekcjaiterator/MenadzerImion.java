/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kolekcjaiterator;

import static java.lang.reflect.Array.get;
import static java.lang.reflect.Array.set;
import java.util.ArrayList;

/**
 *
 * @author medel
 */
public class MenadzerImion extends Menadzer{
    
    private ArrayList _elementy = new ArrayList();
    
    @Override
    public Iterator StworzIterator() {
        return new MenadzerImionIterator(this);
    }
    
    public int Ilosc;
        public int getIlosc()
        {
            return _elementy.size();
        }
    public final Object this[int index] {
        getObject() {
            return _elementy.get(index);
        }
        set {
            _elementy.Insert(index, value);
        }
    }
    
}
