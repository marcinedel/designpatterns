/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kolekcjaiterator;

/**
 *
 * @author medel
 */
public class MenadzerImionIterator extends Iterator {
    
    private MenadzerImion _kontener;
    private int _obecny = 0;
    
    public MenadzerImionIterator(MenadzerImion kontener)
    {
        _kontener = kontener;
    }

    MenadzerImionIterator(MenadzerImion aThis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public Object Pierwszy() 
    {
        return _kontener[0];
    }

    @Override
    public Object Nastepny() 
    {
        Object ret = null;
        if (_obecny < _kontener.Ilosc - 1)
        {
            ret = _kontener[++_obecny];
        }

        return ret;
    }

    @Override
    public boolean CzyKoniec() {
        return _obecny >= _kontener.Ilosc;
    }

    @Override
    public Object PobierzElement() {
        return _kontener[_obecny];
    }
    
}
