/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package temperaturyadapter;

/**
 *
 * @author medel
 */
public class TemperaturyAdapter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Sensor celsjusz = new Adapter(new FahrenheitSensor());
        
        System.out.println("Fahrenheit Sensor pokazuje temperaturę: "+ celsjusz.GetTemperatura()+" 'C");
    }
    
}
