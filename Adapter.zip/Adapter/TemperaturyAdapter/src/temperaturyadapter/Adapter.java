/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package temperaturyadapter;

/**
 *
 * @author medel
 */
class Adapter extends Sensor{
    FahrenheitSensor fs;
    public Adapter(FahrenheitSensor fs)
    {
        this.fs=fs;
    }
    @Override
    public float GetTemperatura() {
        return (fs.GetTemperatura() - 32.0f)*5.0f/9.0f;
    }
    
}
