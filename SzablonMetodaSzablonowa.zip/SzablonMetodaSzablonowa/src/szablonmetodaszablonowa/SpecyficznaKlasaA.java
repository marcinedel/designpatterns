/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package szablonmetodaszablonowa;

/**
 *
 * @author medel
 */
class SpecyficznaKlasaA extends KlasaAbstrakcyjna{

    @Override
    public void ZrobCos() {
        System.out.println("SpecyficznaKlasa.ZrobCos()");
    }

    @Override
    public void JakasInnaMetoda() {
        System.out.println("SpecyficznaKlasaA.JkasInnaMetoda()");
    }
    
    
    
}
