/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package szablonmetodaszablonowa;

/**
 *
 * @author medel
 */
public class Program {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        KlasaAbstrakcyjna aA = new SpecyficznaKlasaA();
        aA.MetodaSzablonowa();
        
        KlasaAbstrakcyjna aB = new SpecyficznaKlasaB();
        aB.MetodaSzablonowa();
        
       
    }
    
}
