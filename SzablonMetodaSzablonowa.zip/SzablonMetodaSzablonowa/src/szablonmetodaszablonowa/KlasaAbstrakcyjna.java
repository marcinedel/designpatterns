/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package szablonmetodaszablonowa;

/**
 *
 * @author medel
 */
abstract class KlasaAbstrakcyjna {

    public abstract void ZrobCos();
    public abstract void JakasInnaMetoda();
    
    public void MetodaSzablonowa()
    {
        ZrobCos();
        JakasInnaMetoda();
        System.out.println("");
    }
    
}
