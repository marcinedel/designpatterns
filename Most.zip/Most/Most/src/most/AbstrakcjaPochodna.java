/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package most;

/**
 *
 * @author medel
 */
class AbstrakcjaPochodna extends Abstrakcja{
    
    @Override
    public void MetodaImplementacji()
    {
        System.out.println("SpecyficznaImplementacja MetodaImplementacji");
    }
}
