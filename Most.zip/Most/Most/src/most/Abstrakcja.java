/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package most;

/**
 *
 * @author medel
 */
public class Abstrakcja {
    protected Implementacja implementacja;

    public Implementacja Implementacja;
        
       
        private void setImplementacja(Implementacja value)
        {
            this.implementacja = value;
        }

    public void MetodaImplementacji()
    {
        implementacja.MetodaImplementacji();
    }
}
